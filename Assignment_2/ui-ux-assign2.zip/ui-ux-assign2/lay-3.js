document.addEventListener("DOMContentLoaded", function() {
    const generateBtn = document.querySelector(".generate-btn");
    const poemResult = document.querySelector(".poem-result");

    // Initially hide the result section
    poemResult.style.display = "none";

    generateBtn.addEventListener("click", function() {
        // Show the result section when the button is clicked
        poemResult.style.display = "block";
    });
});